import React, { useState } from 'react';
import './faleConosco.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function FaleConosco() {
  const [tipoAtivo, setTipoAtivo] = useState(null);

  // Função para definir o botão ativo
  const handleTipoClick = (tipo) => {
    setTipoAtivo(tipo);
  };

  return (
    <div className="fale-conosco-container d-flex">
      {/* Div Conteúdo - Lado Esquerdo */}
      <div className="conteudo col-md-6 d-flex flex-column align-items-center justify-content-start p-3 mt-2">
        {/* Título Centralizado */}
        <h1 className="text-center w-100 mb-2">Fale Conosco</h1>

        {/* Subtítulo Nome e Input */}
        <div className="input-group-reduzido w-100 mb-1">
          <h5 className="subtitulo">Nome</h5>
          <input type="text" className="form-control mx-auto" />
        </div>

        {/* Subtítulo Email e Input */}
        <div className="input-group-reduzido w-100 mb-1">
          <h5 className="subtitulo">Email</h5>
          <input type="email" className="form-control mx-auto" />
        </div>

        {/* Div Tipos de Comentário */}
        <div className="tipos-comentario w-100 mb-2">
          <h5 className="subtitulo mb-2">Tipo de Comentário</h5>
          <div className="d-flex justify-content-around">
            <button
              className={`btn btn-outline-primary tipo-comentario-btn ${tipoAtivo === 'Dúvida' ? 'btn-ativo' : ''}`}
              onClick={() => handleTipoClick('Dúvida')}
            >
              Jornal
            </button>
            <button
              className={`btn btn-outline-secondary tipo-comentario-btn ${tipoAtivo === 'Sugestão' ? 'btn-ativo' : ''}`}
              onClick={() => handleTipoClick('Sugestão')}
            >
              Sugestão
            </button>
            <button
              className={`btn btn-outline-success tipo-comentario-btn ${tipoAtivo === 'Reclamação' ? 'btn-ativo' : ''}`}
              onClick={() => handleTipoClick('Reclamação')}
            >
              Reclamação
            </button>
          </div>
        </div>

        {/* Dropdown com Opções Centralizado */}
        <div className="dropdown-container w-100 mb-1">
          <h5 className="subtitulo">Assunto</h5>
          <div className="dropdown input-reduzido mx-auto dropdown-custom d-flex justify-content-between align-items-center">
            <span>Selecione um Assunto</span>
            <button
              className="btn dropdown-toggle p-0 border-0 bg-transparent"
              type="button"
              id="dropdownMenuButton"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
            </button>
          </div>
          <ul className="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
            <li><a className="dropdown-item" href="#">Produto</a></li>
            <li><a className="dropdown-item" href="#">Serviço</a></li>
            <li><a className="dropdown-item" href="#">Atendimento</a></li>
            <li><a className="dropdown-item" href="#">Outros</a></li>
            <li><a className="dropdown-item" href="#">Feedback</a></li>
          </ul>
        </div>

        {/* Subtítulo Comentário e Textarea */}
        <div className="input-group-reduzido w-100 mb-1">
          <h5 className="subtitulo">Comentário</h5>
          <textarea className="form-control mx-auto textarea-reduzido" rows="3" style={{ resize: 'none' }} />
        </div>

        {/* Botão Enviar */}
        <div className="d-flex justify-content-end w-100">
          <button className="btn btn-primary btn-md">Enviar</button>
        </div>
      </div>

      {/* Div Imagem - Lado Direito */}
      <div className="imagem col-md-6">
        <img src="../img/faleConosco.svg" className="img-fluid w-100 h-100" alt="Imagem de contato" />
      </div>
    </div>
  );
}

export default FaleConosco;
