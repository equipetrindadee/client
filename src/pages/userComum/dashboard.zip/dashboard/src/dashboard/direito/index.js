import React, { useState } from 'react';
import './direito.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';
import Box from '@mui/material/Box';

function Direito() {
  const [selectedDate, setSelectedDate] = useState(null);

  return (
    <div className="calendar-container">
      {/* Usando um Box para limitar o tamanho e tornar responsivo */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          width: '100%',
          maxWidth: '100%', // Define um máximo para a largura
          padding: '10px',
          boxSizing: 'border-box',
          overflow: 'hidden',
        }}
      >
         <LocalizationProvider dateAdapter={AdapterDayjs}>
          {/* Estilizando o DateCalendar para ajustar ao container */}
          <DateCalendar
            value={selectedDate}
            onChange={(newValue) => setSelectedDate(newValue)}
            sx={{
              width: '100%',
              maxWidth: '100%',
              '& .MuiPickersCalendarHeader-root, & .MuiDayCalendar-monthContainer': {
                width: '100%',


                '& .MuiPickersDay-root': {
                  fontSize: '1.15rem', // Aumenta o tamanho dos dias
                  width: '44px',
                  height: '44px',
                },
                
                '& .MuiPickersCalendarHeader-label': {
                  fontSize: '1.5rem', // Aumenta o tamanho do texto do mês
                },
                '& .MuiPickersArrowSwitcher-button': {
                  transform: 'scale(1.4)', // Aumenta o tamanho das setas
                },
                '& .MuiDayCalendar-weekDayLabel': {
                  fontSize: '1.3rem', // Aumenta o tamanho dos dias da semana
                },
              },
              '@media (max-width: 1280px)': {
                '& .MuiPickersDay-root': {
                  fontSize: '1.15rem', // Aumenta o tamanho dos dias
                  width: '44px',
                  height: '44px',
                },
                '& .MuiPickersCalendarHeader-label': {
                  fontSize: '1.5rem', // Aumenta o tamanho do texto do mês
                },
                '& .MuiPickersArrowSwitcher-button': {
                  transform: 'scale(1.4)', // Aumenta o tamanho das setas
                },
                '& .MuiDayCalendar-weekDayLabel': {
                  fontSize: '1.3rem', // Aumenta o tamanho dos dias da semana
                },
              },
              '@media (max-width: 900px)': {
                '& .MuiPickersDay-root': {
                  fontSize: '1.2rem', // Aumenta o tamanho dos dias
                  width: '44px',
                  height: '44px',
                },
                '& .MuiPickersCalendarHeader-label': {
                  fontSize: '1.5rem', // Aumenta o tamanho do texto do mês
                },
                '& .MuiPickersArrowSwitcher-button': {
                  transform: 'scale(1.4)', // Aumenta o tamanho das setas
                },
                '& .MuiDayCalendar-weekDayLabel': {
                  fontSize: '1.3rem', // Aumenta o tamanho dos dias da semana
                },
              },
              '@media (max-width: 600px)': {
                transform: 'scale(0.9)',
                transformOrigin: 'top center',
              },
            }}
          />
        </LocalizationProvider>
      </Box>
    </div>
  );
}

export default Direito;
