import React from 'react';
import './dashboard.css'
import Direito from './direito';
import Esquerdo from './esquerdo';

import FaleConosco from './faleConosco';
import ColunistaUsuario from './colunistas';
import 'bootstrap/dist/css/bootstrap.min.css';




function Dashboard() {
  return (
    <div>
      {/* <div className='teste2' >
        
        <h2>Exemplo</h2>
        <div className="teste">
        
        <Direito />
        </div>
            

        
      </div> */}

      {/* <FaleConosco /> */}

      <ColunistaUsuario />
      
    </div>
  );
}

export default Dashboard;