import React, { useState } from 'react';
import './esquerdo.css';
import { Button, Modal } from 'react-bootstrap';
import 'bootstrap-icons/font/bootstrap-icons.css';

function Esquerdo() {
  const [show, setShow] = useState(false);
  const [activeIcon, setActiveIcon] = useState(null);
  const [selectedNotification, setSelectedNotification] = useState(null);
  const [message, setMessage] = useState(''); // Estado para armazenar a mensagem no textarea
  const [respondClicks, setRespondClicks] = useState(0); // Contador de cliques no botão "Responder"
  const [messageIndex, setMessageIndex] = useState(0); // Index da mensagem atual

  // Lista de mensagens pré-prontas
  const predefinedMessages = [
    "Olá, tudo bem?",
    "Como posso ajudar?",
    "Recebi sua mensagem, obrigado!",
    "Parabens Matheus Você é o Cara!!! 😍😍😍",
    "Estou à disposição para mais informações.",
    "Aguardo sua resposta."
  ];

  const notifications = [
    {
      imgSrc: '../img/perfil1.jfif',
      name: 'Joaquin de Silva',
      message: 'Te mandou uma notificação',
      role: 'Professor',
    },
    {
      imgSrc: '../img/perfil2.jfif',
      name: 'Luciane Almeida Lopes',
      message: 'Te mandou uma notificação',
      role: 'Professora',
    },
    {
      imgSrc: '../img/perfil3.jfif',
      name: 'Carioca Games',
      message: 'Te mandou uma notificação',
      role: 'Gamer',
    },
    {
      imgSrc: '../img/perfil4.jpeg',
      name: 'Miriã Fernandes',
      message: 'Te mandou uma notificação',
      role: 'Chefinha',
    },
  ];

  const handleClose = () => {
    setShow(false);
    setRespondClicks(0); // Reseta o contador de cliques ao fechar o modal
  };

  const handleShow = (notification) => {
    setShow(true);
    setSelectedNotification(notification);
    setActiveIcon(null);

    // Atualiza a mensagem do textarea com base no índice atual da lista
    setMessage(predefinedMessages[messageIndex]);

    // Avança para a próxima mensagem, ou volta ao início da lista
    setMessageIndex((prevIndex) => (prevIndex + 1) % predefinedMessages.length);
  };

  const handleIconClick = (icon) => {
    setActiveIcon(icon);
  };

  const handleRespond = () => {
    // Se for o segundo clique, fechar o modal
    if (respondClicks === 1) {
      handleClose();
    } else {
      setMessage(''); // Limpa o textarea no primeiro clique
      setRespondClicks(respondClicks + 1); // Incrementa o contador de cliques
    }
  };

  return (
    <div>
      {notifications.map((notification, index) => (
        <div key={index} className="aluno_dashboard_cards">
          <Button 
            className="button_notificacoes_aluno"
            variant="" 
            onClick={() => handleShow(notification)}
          >
            <div className="button_notificacoes_aluno_estrutura">
              <div className="button_notificacoes_aluno_conteudo_img imagem-perfil-universal"> 
                <img src={notification.imgSrc} alt={`img${index}`} />
              </div>
              <div className="button_notificacoes_aluno_conteudo_texto"> 
                <h3>{notification.name}</h3>
                <p>{notification.message}</p>
              </div>
            </div>
          </Button>
        </div>
      ))}

      {/* Modal */}
      <Modal show={show} onHide={handleClose}>
        <Modal.Header>
          <div className="modal_notificacoes_aluno_estrutura">
            <div className="modal_notificacoes_aluno_conteudo_img imagem-perfil-universal">
              <img src={selectedNotification?.imgSrc} alt="img" />
            </div>
            <div className="modal_notificacoes_aluno_conteudo_texto">
              <h3>{selectedNotification?.name}</h3>
              <p>{selectedNotification?.role}</p>
            </div>
            <div className="modal_notificacoes_aluno_botao_fechar">
              <Button variant="" onClick={handleClose}>
                <i className="bi bi-x-circle-fill"></i>
              </Button>
            </div>
          </div>
        </Modal.Header>

        <Modal.Body>
          <textarea 
            className="modal_notificacoes_aluno_textarea"
            value={message} // Define o valor do textarea como o estado "message"
            onChange={(e) => setMessage(e.target.value)} // Atualiza o estado conforme o usuário digita
          ></textarea>
        </Modal.Body>

        <Modal.Footer>
          <div className="modal_notificacoes_aluno_footer">
            <Button variant="" onClick={handleRespond}>
              Responder
            </Button>
            <div className="modal_notificacoes_aluno_footer_hands">
              <i 
                className={`bi ${activeIcon === 'thumbsDown' ? 'bi-hand-thumbs-down-fill' : 'bi-hand-thumbs-down'}`} 
                onClick={() => handleIconClick('thumbsDown')}
              ></i>
              <i 
                className={`bi ${activeIcon === 'thumbsUp' ? 'bi-hand-thumbs-up-fill' : 'bi-hand-thumbs-up'}`} 
                onClick={() => handleIconClick('thumbsUp')}
              ></i>
            </div>
          </div>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default Esquerdo;
