import React, { useState } from 'react';
import './faleConosco.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function FaleConosco() {
  const [tipoAtivo, setTipoAtivo] = useState(null);

  // Função para definir o botão ativo
  const handleTipoClick = (tipo) => {
    setTipoAtivo(tipo);
  };

  return (
    <div className="fale-conosco-container d-flex">
      {/* Div Conteúdo - Lado Esquerdo */}
      <div className="conteudo_fale-conosco col-md-6 d-flex flex-column align-items-center justify-content-start p-3 mt-2">
        {/* Título Centralizado */}
        <h1 className="text-center_fale-conosco w-100 mb-2">FALE CONOSCO</h1>

        {/* Subtítulo Nome e Input */}
        <div className="fale_conosco-input-group w-100 mb-1">
          <h5 className="subtitulo_fale-conosco">Nome</h5>
          <input type="text" className="form-control mx-auto" />
        </div>

        {/* Subtítulo Email e Input */}
        <div className="fale_conosco-input-group w-100 mb-1">
          <h5 className="subtitulo_fale-conosco">Email</h5>
          <input type="email" className="form-control mx-auto" />
        </div>

        {/* Div Tipos de Comentário */}
        <div className="tipos-comentario-conosco w-100 mb-2">
          <h5 className="subtitulo_fale-conosco mb-2">Tipo de Comentário</h5>
          <div className="d-flex justify-content-around">
            <button
              className={`btn btn-outline-primary fale_conosco-tipo-comment ${tipoAtivo === 'Dúvida' ? 'fale_conosco-btn-ativo' : ''}`}
              onClick={() => handleTipoClick('Dúvida')}
            >
              <p>Jornal</p>
            </button>
            <button
              className={`btn btn-outline-secondary fale_conosco-tipo-comment  ${tipoAtivo === 'Sugestão' ? 'fale_conosco-btn-ativo' : ''}`}
              onClick={() => handleTipoClick('Sugestão')}
            >
              <p>Sugestão</p>
            </button>
            <button
              className={`btn btn-outline-success fale_conosco-tipo-comment ${tipoAtivo === 'Reclamação' ? 'fale_conosco-btn-ativo' : ''}`}
              onClick={() => handleTipoClick('Reclamação')}
            >
              <p>Reclamação</p>
            </button>
          </div>
        </div>

        {/* Dropdown com Opções Centralizado */}
        <div className="dropdown-container w-100 mb-1">
          <div className="dropdown fale_conosco-input-reduzido mx-auto fale_conosco-dropdown-custom d-flex justify-content-between align-items-center">
            <span className='fale_conosco-span'>Colunas</span>
            <button
              className="btn dropdown-toggle p-0 border-0 bg-transparent"
              type="button"
              id="dropdownMenuButton"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
            </button>
          </div>
          <ul className="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
            <li><a className="dropdown-item" href="#">Produto</a></li>
            <li><a className="dropdown-item" href="#">Serviço</a></li>
            <li><a className="dropdown-item" href="#">Atendimento</a></li>
            <li><a className="dropdown-item" href="#">Outros</a></li>
            <li><a className="dropdown-item" href="#">Feedback</a></li>
          </ul>
        </div>

        {/* Subtítulo Comentário e Textarea */}
        <div className="input-group-reduzido w-100 mb-1">
          <h5 className="subtitulo">Comentário</h5>
          <textarea className="form-control mx-auto fale-conosco_textarea-reduzido" rows="3" style={{ resize: 'none' }} />
        </div>

        {/* Botão Enviar */}
        <div className="d-flex justify-content-end w-100">
          <button className="button_fale-avisar btn btn-primary btn-md"><p>Enviar</p></button>
        </div>
      </div>

      {/* Div Imagem - Lado Direito */}
      <div className="fale_conosco-imagem col-md-6">
        <img src="../img/faleConosco.svg" className="img-fluid w-100 h-100" alt="Imagem de contato" />
      </div>
    </div>
  );
}

export default FaleConosco;
