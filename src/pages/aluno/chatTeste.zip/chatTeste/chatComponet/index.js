import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import './chatComponet.css';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import Table from 'react-bootstrap/Table';

function Chat({ selectedUser }) {
  if (!selectedUser) {
    return <div className="aluno_chat-container">Selecione um usuário para começar a conversa</div>;
  }

  // Definindo o popoverContent
  const popoverContent = {
    tamires: (
      <Popover.Body>
        <div className='popoverBodyChatUserInforHeader'>
          <img src="../../img/userChatComponent.svg" className="userChatMenssagePopOver" alt="Tamires" />
          <h4 className='popoverBodyChatUserInforHeader-userName'>Tamires</h4>
        </div>
        <div className='popoverBodyChatUserInforBody'>
          <ul className='popoverBodyChatUserInforBodyUl'>
            <li className='popoverBodyChatUserInforBodyLi'>
              <i className='bx bxs-school'></i>
              <h6 className='popoverBodyChatUserInforBodyH6'>2 E.M</h6>
            </li>
            <li className='popoverBodyChatUserInforBodyLi'>
              <i className='bx bx-columns'></i>
              <h6 className='popoverBodyChatUserInforBodyH6'>Escola XYZ</h6>
            </li>
            <li className='popoverBodyChatUserInforBodyLi'>
              <i className='bx bxs-pin'></i>
              <h6 className='popoverBodyChatUserInforBodyH6'>Desfixar conversa</h6>
            </li>
          </ul>
        </div>
      </Popover.Body>
    ),
    palavreando: (
      <Popover.Body>
        <div className='popoverBodyChatUserInforHeader'>
          <img src="../../img/sidebarChatColunmPalavreando.svg" className="userChatMenssagePopOver" alt="Palavreando" />
          <h4 className='popoverBodyChatUserInforHeader-userName'>Palavreando</h4>
        </div>
        <div className='popoverBodyChatUserInforBody'>
          <h4 className='popoverBodyChatUserBodyIntegrantes'>INTEGRANTES</h4>
          <ul className='popoverBodyChatUserInforBodyUl'>
            <li className='popoverBodyChatUserIntegrantesBody'>
              <img src="../../img/Percy.svg" className="userChatImgIntegrante" alt="Palavreando" />
              <div className='popoverBodyChatUserInforBodydivClass'>
                <h6 className='popoverBodyChatUserInforIntegranteH6'>Fulano Beltrano dos Campos</h6>
                <p className='popoverBodyChatUserInforBodyIntegrantesClass'>6 Ano do ensino fundamental</p>
              </div>
            </li>
            <li className='popoverBodyChatUserIntegrantesBody'>
              <img src="../../img/Percy.svg" className="userChatImgIntegrante" alt="Palavreando" />
              <div className='popoverBodyChatUserInforBodydivClass'>
                <h6 className='popoverBodyChatUserInforIntegranteH6'>Fulano Beltrano dos Campos</h6>
                <p className='popoverBodyChatUserInforBodyIntegrantesClass'>6 Ano do ensino fundamental</p>
              </div>
            </li>
            <li className='popoverBodyChatUserIntegrantesBody'>
              <img src="../../img/Percy.svg" className="userChatImgIntegrante" alt="Palavreando" />
              <div className='popoverBodyChatUserInforBodydivClass'>
                <h6 className='popoverBodyChatUserInforIntegranteH6'>Fulano Beltrano dos Campos</h6>
                <p className='popoverBodyChatUserInforBodyIntegrantesClass'>6 Ano do ensino fundamental</p>
              </div>
            </li>
          </ul>
        </div>
      </Popover.Body>
    ),
  };

  // Obtendo o nome do usuário para o cabeçalho
  const userName = selectedUser.name === 'tamires' ? 'Tamires' : 'Palavreando';
  const popoverKey = selectedUser.name === 'tamires' ? 'tamires' : 'palavreando';

  return (
    <div className="aluno_chat-container">
      <div className="aluno_chat-header">
        <div className="aluno_chat-header-withImg">
          <img src={selectedUser.img} className="userChatMenssage" alt={userName} />
          <div className="aluno_chat-messageInformationUserStatus">
            <h5 className="aluno_chat-messageStatus-userName">{userName}</h5>
            <p className="aluno_chat-messageStatus">{`${userName} está digitando...`}</p>
          </div>
        </div>
        <div>
          {['bottom'].map((placement) => (
            <OverlayTrigger
              trigger="click"
              key={placement}
              placement={placement}
              overlay={
                <Popover id={`popover-positioned-${placement}`} className='aluno_chat-header-popoverUserInfo'>
                  {popoverContent[popoverKey]}  {/* Usando popoverKey para acessar o conteúdo */}
                </Popover>
              }
            >
              <div className='aluno_chat-header3points'><i className='bx bx-dots-horizontal-rounded'></i></div>
            </OverlayTrigger>
          ))}
        </div>
      </div>

      <div className="aluno_chat-body">
        <div className="aluno_chat-message left">
          <img src={selectedUser.img} className="userChatMenssage" alt={userName} />
          <div className="aluno_chat-message-content">
            <p className="aluno_chat-message-contentLeftUser">{selectedUser.lastMessage}</p>
          </div>
        </div>
        <div className="aluno_chat-message right">
          <div className="aluno_chat-message-content">
            <p className="aluno_chat-message-contentRightUser">
              Esta é uma mensagem de exemplo enviada pelo usuário atual...
            </p>
          </div>
          <img src="../../img/userChatComponent.svg" className="userChatMenssage" alt="Current user" />
        </div>
      </div>

      <div className="aluno_chat-footer">
        <input
          type="text"
          className="form-control aluno_chat-footer-input"
          placeholder="Envie sua mensagem..."
        />
        <i className='bx bx-right-arrow-circle arrowChatUserSend'></i>
      </div>
    </div>
  );
}

export default Chat;
