// Sidebar.js
import React, { useState } from 'react';
import './sidbar.css';

function Sidebar({ onSelectUser }) {
  const [selectedUser, setSelectedUser] = useState(null);

  const users = [
    { id: 1, name: 'Tamires', lastMessage: 'Não se esqueça de me avisar', img: '../../img/userChatComponent.svg', time: '10:53', notifications: 10 },
    { id: 2, name: 'Palavreando', lastMessage: 'Não se esqueça de me avisar', img: '../../img/sidebarChatColunmPalavreando.svg', time: '10:53', notifications: 10 }
  ];

  const handleUserClick = (user) => {
    setSelectedUser(user);
    onSelectUser(user);  // Atualiza o usuário selecionado no componente pai
  };

  return (
    <div className="aluno_chatSidebar-container">
      <div className="aluno_chatSidebar-search-bar">
        <input
          type="text"
          className="form-control aluno_chatSidebar-search-input"
          placeholder="Pesquisar um usuário..."
        />
        <i className="bi bi-search aluno_chatSidebar-search-icon"></i>
      </div>

      <div className="aluno_chatSidebar-fixed-section">
        <h6 className="aluno_chatSidebar-titleFixed">Fixados</h6>
        <div className="aluno_chatSidebar-fixed-list">
          {users.map(user => (
            <button
              key={user.id}
              className={`aluno_chatSidebar-user-item ${selectedUser?.id === user.id ? 'selected' : ''}`}
              onClick={() => handleUserClick(user)}
            >
              <img src={user.img} className="aluno_chatSidebar-userImg" alt={user.name} />
              <div className="aluno_chatSidebar-user-itemContent">
                <div className="aluno_chatSidebar-user-itemContentInfo">
                  <h6 className="aluno_chatSidebar-user-name">{user.name}</h6>
                  <p className="aluno_chatSidebar-userLastMenssage">{user.lastMessage}</p>
                </div>
                <div className="aluno_chatSidebar-messageStatusUser">
                  <p className="aluno_chatSidebar-barStatusUser">{user.time}</p>
                  <div className="aluno_chatSidebar-barStatusUser-NotificationPart">
                    <i className="bx bxs-pin pinAluno"></i>
                    <div className="aluno_chatSidebar-barStatusUser-NotificationUser">
                      <p className="aluno_chatSidebar-barStatusUser-NotificationAmount">{user.notifications}</p>
                    </div>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="aluno_chatSidebar-recent-section">
        <h6 className="aluno_chatSidebar-titleRecents">Recentes</h6>
        <div className="aluno_chatSidebar-recent-list">
          {users.map(user => (
            <button key={user.id} className="aluno_chatSidebar-user-item">
              <img src={user.img} className="aluno_chatSidebar-userImg" alt={user.name} />
              <div className="aluno_chatSidebar-user-itemContent">
                <div className="aluno_chatSidebar-user-itemContentInfo">
                  <h6 className="aluno_chatSidebar-user-name">{user.name}</h6>
                  <p className="aluno_chatSidebar-userLastMenssage">{user.lastMessage}</p>
                </div>
                <div className="aluno_chatSidebar-messageStatusUser">
                  <p className="aluno_chatSidebar-barStatusUser">{user.time}</p>
                  <div className="aluno_chatSidebar-barStatusUser-NotificationPart">
                    <i className="bx bxs-pin pinAluno"></i>
                    <div className="aluno_chatSidebar-barStatusUser-NotificationUser">
                      <p className="aluno_chatSidebar-barStatusUser-NotificationAmount">{user.notifications}</p>
                    </div>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Sidebar;
