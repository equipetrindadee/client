import React, { useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import '../../aluno/processodePostagem/processodePostagem.css';
import { Container, Row, Col } from 'react-bootstrap';
import NavBaraluno from '../../navBar/navBarAluno';
import ErrorCelular from '../../components/error';



export const ProcessodePostagem = () => {

    useEffect(() => {
        const buttonPergunta = document.getElementById("enviadoProcessoPostagem");
        const activeButton = document.getElementById("buttonActive_processoPostagem");
        const editarButton = document.getElementById("buttonVoltar_Editar_ProcessoPostagem")



        const handleButtonClick = () => {
            if (activeButton) {
                activeButton.classList.toggle('buttonPergunta-Active-processoPostagem');
            }
            if (editarButton) {
                editarButton.classList.toggle('buttonEditar-Active-processoPostagem')
            }
        };

        if (buttonPergunta) {
            buttonPergunta.addEventListener("click", handleButtonClick);
        }

        // Cleanup

        return () => {
            if (buttonPergunta) {
                buttonPergunta.removeEventListener("click", handleButtonClick);
            }
        };

    }, []);


    return (

        <div>

            <div className='errorCelular-processoPostagem'>
                <ErrorCelular />
            </div>

            <div className='fullContainer-div-processoPostagem'>

                <NavBaraluno />

                {/* Container Processo de Postagem */}
                <section className="container-processodePostagem">

                    {/* Topo Processo de Postagem */}
                    <Row className="top-Educador">

                        <Col>

                            {/* Logo Processo de Postagem */}
                            <h1 className="title-processodePostagem"> O EDUCADOR</h1>
                            <p className="subtitle-processodePostagem">Te manter informado é a nossa função</p>
                            <div className="linha-processodePostagem"></div>

                        </Col>

                    </Row>

                    {/* Conteudo Processo de Postagem */}
                    <Col className="content-processodePostagem">

                        {/* Jornal Processo de Postagem */}
                        <div className="row">

                            {/* Informação Processo de Postagem */}
                            <div className="infoJornal-processodePostagem">

                                {/* Autor Jornal Processo de Postagem */}
                                <div className="autor-processorPostagem">

                                    <img src="../img/processoPostagemJornalista.svg" alt="teste" className="imagemAutor-processodePostagem" />

                                    <div>

                                        <p className="nome-processodePostagem">Por Catarina Benedetto</p>
                                        <p className="data-processodePostagem">01/01/2001</p>

                                    </div>

                                </div>

                                {/* Audio Jornal Processo de Postagem */}
                                <div className='audio-processorPostagem'>

                                    <i class='bx bx-play'></i>
                                    <div className='linhaAudio-processorPostagem'></div>

                                </div>

                                {/* Titulo Jornal Processo de Postagem */}
                                <h3 className='titlecontent-processorPostagem'>O papel das olímpiadas</h3>

                                {/* Primeiro paragrafo Processo de Postagem */}
                                <section className="firstParagrafo-processorPostagem">

                                    <p className="campoTexto1-processorPostagem">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus non malesuada mi. In pellentesque nunc sit amet erat sodales cursus. Aenean scelerisque nunc id ipsum varius, a ultricies metus convallis. Donec vitae nulla dolor. Morbi venenatis tincidunt metus, in elementum felis pharetra ac. Etiam vitae felis vel felis feugiat gravida quis sed nulla. Mauris efficitur tempor enim, quis iaculis nisi hendrerit vel.</p>
                                    <div className="campoImagem1-processorPostagem"></div>

                                </section>

                                {/* Segundo paragrafo Processo de Postagem */}
                                <section className="segundoParagrafo-processorPostagem">

                                    <p className="campoTexto2-processorPostagem">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus non malesuada mi. In pellentesque nunc sit amet erat sodales cursus. Aenean scelerisque nunc id ipsum varius, a ultricies metus convallis. Donec vitae nulla dolor. Morbi venenatis tincidunt metus, in elementum felis pharetra ac. Etiam vitae felis vel felis feugiat gravida quis sed nulla. Mauris efficitur tempor enim, quis iaculis nisi hendrerit vel.</p>

                                </section>

                                {/* Terceiro paragrafo Processo de Postagem */}
                                <section className="terceiroParagrafo-processorPostagem">

                                    <div className="campoImagem2-processorPostagem"></div>
                                    <p className="campoTexto3-processorPostagem">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus non malesuada mi. In pellentesque nunc sit amet erat sodales cursus. Aenean scelerisque nunc id ipsum varius, a ultricies metus convallis. Donec vitae nulla dolor. Morbi venenatis tincidunt metus, in elementum felis pharetra ac. Etiam vitae felis vel felis feugiat gravida quis sed nulla. Mauris efficitur tempor enim, quis iaculis nisi hendrerit vel.</p>

                                </section>

                                {/* Quarto paragrafo Processo de Postagem */}
                                <section className="quartoParagrafo-processorPostagem">

                                    <div className="campoImagem3-processorPostagem"></div>
                                    <p className="campoTexto4-processorPostagem">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus non malesuada mi. In pellentesque nunc sit amet erat sodales cursus. Aenean scelerisque nunc id ipsum varius, a ultricies metus convallis. Donec vitae nulla dolor. Morbi venenatis tincidunt metus, in elementum felis pharetra ac. Etiam vitae felis vel felis feugiat gravida quis sed nulla. Mauris efficitur tempor enim, quis iaculis nisi hendrerit vel.</p>

                                </section>

                                {/* Footer Jornal Processo de Postagem */}
                                <footer className="fotter-processorPostagem">

                                    {/* Saiba mais Processo de Postagem */}
                                    <h2 className="saibaMais-processoPostagem">Saiba Mais</h2>

                                    {/* Link do QrCode Processo de Postagem */}
                                    <div className="linkSaiba-processorPostagem">

                                        <p>nt here, content here', making it look like</p>
                                        <div className="qrCode-processorPostagem"></div>

                                    </div>

                                    {/* Link do QrCode Processo de Postagem */}
                                    <div className="linkSaiba-processorPostagem">

                                        <p>nt here, content here', making it look like</p>
                                        <div className="qrCode-processorPostagem"></div>

                                    </div>

                                </footer>

                            </div>


                            {/* Area Colunista Processo de Postagem */}
                            <section className="areaColunista-processodePostagem">

                                <h1 className="titleAreaColunista-processodePostagem">Área Colunista</h1>

                                {/* Botões Area Colunista Processo de Postagem */}
                                <button className="buttoEnviar-processodePostagem" id='buttonActive_processoPostagem' data-bs-toggle="modal" data-bs-target="#modalPergunta-processoPostagem">Enviar para Revisão <i class='bx bx-paper-plane'></i></button>
                                <button className="buttoEditar-processodePostagem" id='buttonVoltar_Editar_ProcessoPostagem'>Voltar para Editar <i class='bx bxs-edit'></i></button>

                            </section>

                        </div>

                    </Col>


                </section>

                {/* Modal pergunta sobre o envio do Artigo Processo de Postagem*/}
                <div class="modal fade modalPergunta-processoPergunta" id="modalPergunta-processoPostagem" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

                    <div class="modal-dialog">

                        <div class="modal-content modalPergunta-processoPostagem">

                            {/* Modal header Processo de Postagem*/}
                            <div class="modal-header fecharPergunta-modal-processoPostagem">

                                <h1 class="modal-title fs-5 titleModal-enviar-processoPostagem" id="exampleModalLabel">VOCÊ TEM CERTEZA QUE DESEJA ENVIAR ESSE ARTIGO?</h1>
                                <button type="button" class="buttonFechar-Modal-processoPostagem" data-bs-dismiss="modal" aria-label="Close"><i class="bi bi-x-lg"></i></button>

                            </div>

                            {/* Modal body Processo de Postagem*/}
                            <div class="modal-body">
                                <h2>Lembre-se de que, após clicar em SIM, não será possível cancelar o envio do artigo.</h2>
                            </div>

                            {/* Modal footer Processo de Postagem*/}
                            <div class="modal-footer footerPergunta-modal-processoPostagem">

                                <button type="button" class="btn btn-secondary buttonNao-modal-processoPostagem" data-bs-dismiss="modal">NÃO</button>
                                <button type="button" class="btn btn-primary buttonSim-modal-processoPostagem" data-bs-toggle="modal" data-bs-target="#enviadoSucesso" id='enviadoProcessoPostagem'>SIM</button>

                            </div>

                        </div>

                    </div>

                </div>

                {/* Modal de colusao sobre o  envio do Artigo Processo de Postagem*/}
                <div class="modal fade" id="enviadoSucesso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

                    <div class="modal-dialog modal-dialog-centered">

                        <div class="modal-content modalParabens-processoPostagem">

                            {/* Modal header Processo de Postagem*/}
                            <div class="modal-header modal-fechar-processoPostagem">

                                <button type="button" class="buttonFechar-Modal2-processoPostagem" data-bs-dismiss="modal" aria-label="Close"><i class='bx bxs-x-circle'></i></button>

                            </div>

                            {/* Modal body Processo de Postagem*/}
                            <div class="modal-body info-modal-processoPostagem">

                                <div class="info-body-processoPostagem">

                                    <h1>PARABÉNS!</h1>
                                    <p>Parabéns pelo envio da sua matéria para avaliação! Agradecemos muito o seu esforço e o tempo dedicado a isso.</p>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>


            </div>

        </div>
    )
}

export default ProcessodePostagem;