import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import '../ladoEsquedo/ladoEsquedo.css';
import Notificacoes from './notificacoes/notificacoes';
import { Carousel } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const imagesCarrossel = [
    { src: '', route: '/telainicial' },
    { src: '', route: '/nav' },
    { src: '', route: '/aluno' },
    { src: '', route: '/templete' },
    { src: '', route: '/ProcessoDePostagem' },
    { src: '', route: '/chat' },
    { src: '', route: '/meusArtigos' },
    { src: '', route: '/adicionarPagina' }
];

export const LadoEsquedo = () => {
    const navigate = useNavigate();

    const handleImageClick = (route) => {
        navigate(route);
    };

    return (
        <div className="col-md-8 aluno_dashboard_ladoEsquerdo">
            <div className="div-content aluno_dashboard_templates ">
                {/* Carrossel */}
                <div className="aluno_dashboard-carousel-row">
                        <Carousel
                            indicators={false}
                            controls={true}
                            prevIcon={<i className="bi bi-chevron-left"></i>}
                            nextIcon={<i className="bi bi-chevron-right"></i>}>

                            {[...Array(2)].map((_, index) => (
                                <Carousel.Item key={index}>
                                <div className="aluno_dashboard-carousel-grid">
                                    {imagesCarrossel.slice(index * 4, index * 4 + 4).map((item, idx) => (
                                        <div 
                                            key={idx} 
                                            className={`aluno_dashboard-carousel-item aluno_dashboard-carousel-item-color${index * 4 + idx + 1}`}
                                            onClick={() => handleImageClick(item.route)}>
                                        </div>
                                    ))}
                                </div>
                            </Carousel.Item>   
                            ))}
                        </Carousel>
                    </div> 
                {/* Carrossel */}
                <div className="aluno_dashboard-carousel-row">
                    
                        <Carousel
                            indicators={false}
                            controls={true}
                            prevIcon={<i className="bi bi-chevron-left"></i>}
                            nextIcon={<i className="bi bi-chevron-right"></i>}>

                            {[...Array(2)].map((_, index) => (
                                <Carousel.Item key={index}>
                                <div className="aluno_dashboard-carousel-grid">
                                    {imagesCarrossel.slice(index * 4, index * 4 + 4).map((item, idx) => (
                                        <div 
                                            key={idx} 
                                            className={`aluno_dashboard-carousel-item aluno_dashboard-carousel-item-color${index * 4 + idx + 1}`}
                                            onClick={() => handleImageClick(item.route)}>
                                        </div>
                                    ))}
                                </div>
                            </Carousel.Item>   
                            ))}
                        </Carousel>
                    </div> 

                    
                {/* Carrossel Responsivo */}
                {/* <div className="aluno_dashboard-carousel-row aluno_dashboard-carousel-row-responsivo">
                    <h4>Templates</h4>
                    <Carousel
                        indicators={false}
                        controls={true}
                        prevIcon={<i className="bi bi-chevron-left"></i>}
                        nextIcon={<i className="bi bi-chevron-right"></i>}
                    >
                        {imagesCarrossel.map((item, index) => (
                            <Carousel.Item key={index}>
                                <div className="aluno_dashboard-carousel-grid aluno_dashboard-carousel-grid-responsivo">
                                    <div
                                        className={`aluno_dashboard-carousel-item aluno_dashboard-carousel-item-color${index + 1}`}
                                        onClick={() => handleImageClick(item.route)}
                                    >
                                        
                                    </div>
                                </div>
                            </Carousel.Item>
                        ))}
                    </Carousel>
                </div> */}
                      
            </div>

            {/* Notificações */}
            <div className="div-content aluno_dashboard_notificacoes">
                <div className='aluno_dashBoard_notificacoes_topo'>
                    <h4>Notificações</h4>
                    <div className='aluno_dashboard_notificacoes_pesquisa d-flex align-items-center'>
                        <input
                            type='text'
                            className='form-control aluno_dashboard_notificacoes_topo_conteudo_input'
                        />
                        <button className='btn aluno_dashboard_notificacoes_topo_conteudo_btn'>
                            <i className='bi bi-search'></i>
                        </button>
                    </div>
                </div>

                <div className="container mt-4 aluno_dashBoard_progresso_scroll">
                    <div className="row aluno_dashBoard_notificacoes_cards_grupo">
                        <Notificacoes />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default LadoEsquedo;
