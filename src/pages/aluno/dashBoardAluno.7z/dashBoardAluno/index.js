import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import '../../aluno/dashBoardAluno/dashBoardAluno.css';


import NavBaraluno from '../../navBar/navBarAluno';
import LadoDireito from './ladoDireito/ladoDireito';
import LadoEsquedo from './ladoEsquedo/ladoEsquedo';


export const DashBoardAluno = () => {

    return (
        <div>
            <div className='navBarAluno_telaDash'>
                {/* navBarAluno */}
                <NavBaraluno/>
            </div>
           

            {/* conteudo */}
                    
                {/* lado esquerdo */}
                <LadoEsquedo/>
                {/* lado direito */}
                <LadoDireito/>
        </div>
    );
}

export default DashBoardAluno;
