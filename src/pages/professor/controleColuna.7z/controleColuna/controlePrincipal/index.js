import React from 'react';
import NavBarProfessor from '../../../navBar/navBarProfessor';
import ContentColuna from '../contentColuna/index.js'

import '../contentColuna/index.js'


function ControleColuna() {
    
    return (
     <div>
      <div className='contentColunaContainer' >
      <NavBarProfessor/>
       
       <ContentColuna/>
      </div>
      
      
     </div>
       
    );
  }
  
  export default ControleColuna;
  
