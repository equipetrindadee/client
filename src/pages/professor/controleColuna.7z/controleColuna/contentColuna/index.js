import React from 'react'

function ContentColuna() {

    return (
        <div>
            <div className='contentColunaBodyContainer'>
                <div className='contentColunaHeaderContentProfessor'>
                    <div className='contentColunaHeaderContentProfessor-interDiv'>
                        <div className='contentColunaHeaderContentProfessor-titleContent'>
                            <h1 className='contentColunaHeaderContentProfessor-titleH1'>CONTROLE DE COLUNAS</h1>
                        </div>
                        <div className='contentColunaHeaderContentProfessor-actionsButtons'>
                            <input
                                type="text"
                                placeholder="Pesquisar um usuário..."
                            />
                            <div className='contentColunaHeaderContentProfessor-buttonsContent'>
                                <button className='contentColunaHeaderContentProfessor-buttonCriarColuna'><i class='bx bx-plus-circle'></i>Criar coluna</button>
                                <button className='contentColunaHeaderContentProfessor-buttonCriarUsuario'><i class='bx bx-plus'></i>Criar Usuário</button>
                            </div>
                        </div>

                    </div>
                    <div className='contentColunaHeaderContentProfessor-lineBottom'></div>
                </div>
                <div className='contentColunaContentProfessor' >

                </div>

            </div>
        </div>

    );
}

export default ContentColuna;
