
import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import "../../professor/dashboardProfessor/dashboardProfessor.css";
import NavBarProf from '../../navBar/navBarProfessor';
import NavBarProfessor from '../../navBar/navBarProfessor';
import Calendario from '../../userComum/calendario';

import { getFirestore, collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../../config/firebaseImgConfig'; 
import {Dropdown} from 'react-bootstrap';
import {DropdownButton} from 'react-bootstrap';

export const DashboardProfessor = () => { // Renomeie para DashboardProfessor
    const [currentIndex, setCurrentIndex] = useState(0);
    const [currentCardIndex, setCurrentCardIndex] = useState(0);
    const [isAnimatingLeft, setIsAnimatingLeft] = useState(false);
    const [isAnimatingRight, setIsAnimatingRight] = useState(false);
    const [animatingCardLeft, setAnimatingCardLeft] = useState(false);
    const [animatingCardRight, setAnimatingCardRight] = useState(false);
    const [itemsToShow, setItemsToShow] = useState(6);
    const [itemsCardShow, setItemsCardShow] = useState(4);
    const [mostrarNavbarMobile, setMostrarNavbarMobile] = useState(false);
    const [mostrarNavbarProf, setMostrarNavbarProf] = useState(true);
    const [professores, setProfessores] = useState([]);
    const [selectedProfessor, setSelectedProfessor] = useState('');
    const [colunas, setColunas] = useState([]); // Novo estado para armazenar as colunas

    const fetchProfessores = async () => {
        try {
            const usersCollection = collection(db, 'users');
            const q = query(usersCollection, where('categoria', '==', 'professor'));
            const querySnapshot = await getDocs(q);

            const listaProfessores = querySnapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data(),
            }));

            setProfessores(listaProfessores);
        } catch (error) {
            console.error('Erro ao buscar os professores:', error);
        }
    };

    const fetchColunas = async () => {
        try {
            const usersCollection = collection(db, 'users');
            const querySnapshot = await getDocs(usersCollection);
    
            const colunasMap = new Set();
            querySnapshot.forEach((doc) => {
                if (doc.data().coluna) {
                    colunasMap.add(doc.data().coluna);
                }
            });
    
            const colunasArray = Array.from(colunasMap);
            setColunas(colunasArray); // Atualiza o estado das colunas
        } catch (error) {
            console.error('Erro ao buscar as colunas:', error);
        }
    };

    

    const handleSelectProfessor = (eventKey) => {
        console.log("Professor selecionado:", eventKey);
        setSelectedProfessor(eventKey);
    };

    useEffect(() => {
        fetchProfessores();
        fetchColunas(); // Chama a função para buscar as colunas
    }, []);

// No useEffect para carregar quando o componente montar
useEffect(() => {
    fetchProfessores();
    fetchColunas(); // Chame para carregar as colunas também
}, []);




    const itemCardDashProf = [
        { id: 1, title: 'EM REVISÃO', card: 'cardRevisao-dashboard-Professor', logo: 'logoRevisao-dashboard-Professor', iconeLogoCard: 'bi bi-pencil-square', colunas: 'colunasRevisao-dashboard-Professor', buttonNotFunction: 'buttonNotFunction'},

        { id: 2, title: 'CONCLUÍDO', card: 'cardConclusao-dashboard-Professor', logo: 'logoConclusao-dashboard-Professor', iconeLogoCard: 'bi bi-patch-check', colunas: 'colunasConclusao-dashboard-Professor', buttonNotFunction: 'buttonNotFunction'},

        { id: 3, title: 'POSTADO', card: 'cardPostado-dashboard-Professor', logo: 'logoPostado-dashboard-Professor', iconeLogoCard: 'bx bx-paper-plane', colunas: 'colunasPostado-dashboard-Professor', buttonNotFunction: 'buttonNotFunction'},

        { id: 4, title: 'NÃO ENTREGUES', card: 'cardNaoEntregue-dashboard-Professor', logo: 'logoNaoEntregue-dashboard-Professor', iconeLogoCard: 'bi bi-exclamation-triangle-fill', colunas: 'colunasNaoEntregue-dashboard-Professor', buttonNotFunction: 'buttonNotificar-dashboard-Professor'}
    ]

    const itemColuns = [
        { id: 1, title: 'Além do Livro', className: 'alemLivroBall-dashboard-professor' },
        { id: 2, title: 'Além das Fronteiras', className: 'alemFronteirasBall-dashboard-professor' },
        { id: 3, title: 'Educação em foco',  className: 'educacaoFocoBall-dashboard-professor' },
        { id: 4, title: 'Monthly dose of english',  className: 'monthlyEnglishBall-dashboard-professor' },
        { id: 5, title: 'Palavreando', className: 'palavreandoBall-dashboard-professor' },
        { id: 6, title: 'Aconteceu na escola', className: 'aconteceuEscolaBall-dashboard-professor' },
        { id: 7, title: 'Tecnologia', className: 'tecnologiaBall-dashboard-professor' },
        { id: 8, title: 'Aventuras na História', className: 'aventurasHistoriaBall-dashboard-professor' },
        { id: 9, title: 'Biofímica em ação', className: 'biofimicaBall-dashboard-professor' },
    ];

    const itemsColunas = [
        { id: 1, title: 'Além do Livro', className: 'alemLivroButton-dashboard-professor', href: '#' },
        { id: 2, title: 'Além das Fronteiras', className: 'alemFronteirasButton-dashboard-professor', href: '#' },
        { id: 3, title: 'Educação em foco', className: 'educacaoFocoButton-dashboard-professor', href: '#' },
        { id: 4, title: 'Monthly dose of english', className: 'monthlyEnglishButton-dashboard-professor', href: '#' },
        { id: 5, title: 'Palavreando', className: 'palavreandoButton-dashboard-professor', href: '#' },
        { id: 6, title: 'Aconteceu na escola', className: 'aconteceuEscolaButton-dashboard-professor', href: 'http://localhost:3000/publicacao' },
        { id: 7, title: 'Tecnologia', className: 'tecnologiaButton-dashboard-professor', href: '#' },
        { id: 8, title: 'Aventuras na História', className: 'aventurasHistoriaButton-dashboard-professor', href: '#' },
        { id: 9, title: 'Biofímica em ação', className: 'biofimicaAcaoButton-dashboard-professor', href: '#' },
    ];



        useEffect(() => {
            
        

        const verificarTamanhoTela = () => {
            if (window.innerWidth <= 820) {
                setMostrarNavbarProf(false);
                setMostrarNavbarMobile(true); // Mostra a navbar mobile se a largura for <= 768px
            } else {
                setMostrarNavbarMobile(false); // Esconde a navbar mobile se a largura for maior que 768px
                setMostrarNavbarProf(true);
            }
        };

        const handleResize = () => {

            if (window.innerWidth < 1200) {
                setItemsToShow(5); 
            } else {
                setItemsToShow(6); // Mostrar 6 colunas
            }

            if (window.innerWidth < 1000) {
                setItemsCardShow(2)
                setItemsToShow(3); // Mostrar 4 colunas
            } else {
                setItemsToShow(5); // Mostrar 6 colunas
            }

            if (window.innerWidth < 769) {
                setItemsToShow(2)
                setItemsCardShow(4)
            } else {
                setItemsToShow(3)
                setItemsCardShow(2)
            }


            if (window.innerWidth > 1000) {
                setItemsToShow(6)
                setItemsCardShow(4)
            }
        };


        window.addEventListener('resize', verificarTamanhoTela);
        window.addEventListener('resize',handleResize)
        verificarTamanhoTela();
        handleResize(); // Chamada inicial para ajustar na primeira renderização

        // Limpa o event listener quando o componente for desmontado
        return () => {
            window.removeEventListener('resize', verificarTamanhoTela, handleResize);
        };
    }, []);

    const handlePrev = () => {
        if (!isAnimatingLeft) {
            setIsAnimatingLeft(true);
            setTimeout(() => {
                setCurrentIndex((prevIndex) => prevIndex === 0 ? itemsColunas.length - 1 : prevIndex - 1);
                setIsAnimatingLeft(false);
            }, 250); // Duração da animação
        }
    };

    const handleNext = () => {
        if (!isAnimatingRight) {
            setIsAnimatingRight(true);
            setTimeout(() => {
                setCurrentIndex((prevIndex) => (prevIndex === itemsColunas.length - 1 ? 0 : prevIndex + 1));
                setIsAnimatingRight(false);
            }, 250); // Duração da animação
        }
    };

    
    const cardDashNext = () => {
        if (!animatingCardRight) {
            setAnimatingCardRight(true);
            setTimeout(() => {
                setCurrentCardIndex((prevIndex) => (prevIndex === itemsColunas.length - 1 ? 0 : prevIndex + 1));
                setAnimatingCardRight(false);
            }, 250); // Duração da animação
        }
    }

    const cardDashPrev = () => {
        if (!animatingCardLeft) {
            setAnimatingCardLeft(true);
            setTimeout(() => {
                setCurrentCardIndex((prevIndex) => prevIndex === 0 ? itemsColunas.length - 1 : prevIndex - 1);
                setAnimatingCardLeft(false);
            }, 250); // Duração da animação
        }
    }

    
    const visibleColunas = [];
    for (let i = 0; i < itemsToShow; i++) {
        visibleColunas.push(colunas[(currentIndex + i) % colunas.length]);
    }
    const visibleitemsCardDash = [];
    for (let i = 0; i < itemsCardShow; i++) {
        visibleitemsCardDash.push(itemCardDashProf[(currentCardIndex + i) % itemCardDashProf.length])
    }
    
        return (
            <div className="container-dashboard-Professor">

            {mostrarNavbarProf && <NavBarProf />}
            {mostrarNavbarMobile && <NavBarProfessor />}

            {/* Dropdown */}
            <div className='dropTeste'>
                <h1>Selecione um Professor</h1>
                <DropdownButton
                    id="dropdown-basic-button"
                    title={selectedProfessor || "Selecione um professor"}
                    onSelect={handleSelectProfessor}
                >
                    {professores.map(professor => (
                        <Dropdown.Item key={professor.id} eventKey={professor.name}>
                            {professor.name}
                        </Dropdown.Item>
                    ))}
                </DropdownButton>
                
            </div>
            

                <div className="dashboard-content-Professor">

                    {/* Logo do proprio Jornal chamado EDUCADOR */}
                    <div className="logoDashboard-logo-Professor">

                        <h1 className="titleLogo-dashboard-Professor">O EDUCADOR</h1>
                        <h3 className="subTitleLogo-dashboard-Professor">TE MANTER INFORMADO É A NOSSA MISSÃO</h3>
                        <div className="linhalogo-dashboard-Professor"></div>

                    </div>
                    {/* Fim da logo */}
                    
                    {/* Mini texto BEM-VINDO, vai mudar para cada Usuario Professor */}
                    <div className="container-bemVindo-dashboardProfessor">
                        <h2 className="bemVindo-dashboard-Professor">
                            Bem vindo(a), {selectedProfessor ? selectedProfessor : "Professor"}{/* Aqui muda o nome */}
                        </h2>
                    </div>
                    {/* Fim do Mini texto BEM-VINDO */}


                    {/* Carrossel do Topo, tela Professor */}
                    <div className="carrosselDashboard-Professor">
                    <i className="bi bi-caret-left-fill arrowLeft" onClick={handlePrev}></i>
                    <div className={`colunaSlide-dashboard-professor ${isAnimatingLeft ? 'animatingLeft' : ''}${isAnimatingRight ? 'animatingRight' : ''}`}>
                        {visibleColunas.map((coluna, index) => (
                            <div key={index} className={`coluna`}>
                                <h3 className='titleColunas-dashboard-professor'>{coluna}</h3>
                                <i className="bi bi-play-circle-fill buttonColunas-dashboard-professor"></i>
                            </div>
                        ))}
                    </div>
                    <i className="bi bi-caret-right-fill arrowRight" onClick={handleNext}></i>
                </div>
                    {/* Fim do Carrossel Topo */}

                    {/* Cards de Visualização do Professor, com carrossel Responsivo */}
                    <div className="cardVisualizacao-dashboard-Professor"> 
                        
                        <i className="bi bi-caret-left-fill arrowLeft arrowCards-Dashboard-Professor" onClick={cardDashPrev}></i>

                        {visibleitemsCardDash.map((item) => (
                            <div key={item.id} className={item.card}>

                                <div className={item.logo}>
                                    <i className={item.iconeLogoCard}></i>
                                </div>

                                <h3>{item.title}</h3>

                                <div className={item.colunas}>
                                    {itemColuns.map((item) => (
                                        <div key={item.id} className='colunasVisualizacao-dashboard-Professor'>
                                            <div className='allConteudo-colunas-dashboard-professor'>
                                                <div className={item.className}>
                                                    <i class='bx bx-radio-circle-marked'></i>
                                                </div>
                                                <h3>{item.title}</h3>
                                            </div>
                                        </div>
                                    ))}
                                </div>

                                <button className={item.buttonNotFunction}>NOTIFICAR TODOS</button>
                            </div>
                        ))}

                        <i className="bi bi-caret-right-fill arrowRight arrowCards-Dashboard-Professor" onClick={cardDashNext}></i>

                    </div>
                    {/* Fim Cards de Visualização do Professor, com carrossel Responsivo */}

                    {/* footer da tela professor */}
                    <footer className="footer-dashboard-Professor">

                        <div className="calendario-dashboard-Professor">
                           <Calendario />
                        </div>

                        <div className='linhaSeparadora-dashboard-Professor'></div>

                        <div className="areaImpressão-dashboard-Professor">
                            
                            <h1>ÁREA DE IMPRESSÃO</h1>

                            <div className='edicaoNova-dashboard-Professor'>

                                <h3 className='nomeEdicao-dashboard-Professor'>EDIÇÃO DE JULHO</h3>

                                <button className='buttonEdicao-dashboard-Professor'>Baixar Arquivo</button>

                            </div>

                            <div className='edicaoNova-dashboard-Professor'>

                                <h3 className='nomeEdicao-dashboard-Professor'>EDIÇÃO DE JUNHO</h3>

                                <button className='buttonEdicao-dashboard-Professor'>Baixar Arquivo</button>

                            </div>

                            <div className='edicaoNova-dashboard-Professor'>

                                <h3 className='nomeEdicao-dashboard-Professor'>EDIÇÃO DE MAIO</h3>

                                <button className='buttonEdicao-dashboard-Professor'>Baixar Arquivo</button>

                            </div>

                        </div>

                    </footer>
                    {/*Fim do footer */}

                </div>

        </div> 
        );
};

export default DashboardProfessor;