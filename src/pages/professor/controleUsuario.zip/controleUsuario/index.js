import React,{ useState} from 'react';
import { Button } from 'react-bootstrap';
import './controleUsuario.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

import ModalEditarUsuario from './modalEditarUsuario';

function ControleUsuario() {;

    // Função para adicionar um novo aluno
    const [alunos, setAlunos] = useState([]);

    
  // Lista de matérias e suas cores correspondentes
  const materias = [
    { nome: 'Matemática', cor: '#ffcccc' },
    { nome: 'Português', cor: '#ccffcc' },
    { nome: 'História', cor: '#ccccff' },
    { nome: 'Ciências', cor: '#ffffcc' },
    { nome: 'Geografia', cor: '#ccffff' },
    { nome: 'Física', cor: '#ffccff' },
    { nome: 'Química', cor: '#ffcc99' },
  ];

  // Lista de imagens
  const imagens = [
    'oruam.jpg',
    'miria.jpeg',
    'tigre.png',
  ];

  // Função para adicionar um novo aluno
  const adicionarAluno = () => {
    const nomes = [
      'João Silva Santos',
      'Maria Oliveira',
      'Pedro Ferreira',
      'Ana Clara',
      'Luiz Henrique',
      'Carla Mendes',
      'Rafael Costa',
      'Juliana Pereira'
    ];

    // Escolher um nome aleatório da lista
    const nomeAleatorio = nomes[Math.floor(Math.random() * nomes.length)];

    // Escolher uma matéria aleatória da lista de matérias
    const materiaAleatoria = materias[Math.floor(Math.random() * materias.length)];

    // Escolher uma imagem aleatória da lista de imagens
    const imagemAleatoria = imagens[Math.floor(Math.random() * imagens.length)];

    const novoAluno = {
      id: alunos.length + 1, // ID único, apenas como exemplo
      nome: nomeAleatorio,
      ano: `${3 + (alunos.length % 4)} E.M.`, // Exemplo de ano (3, 4, 5, 6 E.M.)
      categoria: 'Aluno',
      materia: materiaAleatoria.nome,
      cor: materiaAleatoria.cor, // Cor da matéria
      imagem: imagemAleatoria, // Imagem do aluno
    };
    setAlunos([...alunos, novoAluno]);
  };
    return (
        <div className="controleUsuario_container d-flex justify-content-center align-items-start flex-column">
     
     <Button onClick={adicionarAluno}>
        <i className="bi bi-plus"></i> 
      </Button>
            <header className="controleUsuario_header w-75">
                <div className="controleUsuario_introducao d-flex justify-content-between align-items-center">
                    <h1 className="controleUsuario_titulo">Controle de Usuários</h1>
                    <div className="controleUsuario_pesquisas"></div>
                </div>
                <div className="controleUsuario_headerLinha"></div>
            </header>

            <div className="controleUsuario_body w-75">
                 {/* Tabela de alunos */}
      <table className="table table-striped text-center">
        <thead>
          <tr>
            <th className="controleUsuario_colunaTitulo controleUsuario_colunaPerfil">Perfil</th>
            <th className="controleUsuario_colunaTitulo">Nome</th>
            <th className="controleUsuario_colunaTitulo">Ano</th>
            <th className="controleUsuario_colunaTitulo">Categoria</th>
            <th className="controleUsuario_colunaTitulo">Nome da Coluna</th>
            <th className="controleUsuario_colunaTitulo controleUsuario_colunaEditar">Editar</th>
          </tr>
        </thead>
        <tbody>
          {alunos.map((aluno) => (
            <tr key={aluno.id}>
              <td className="controleUsuario_colunaPerfil controleUsuario_imagemPerfil_perfil d-flex justify-content-center align-items-center">
                <img src="https://via.placeholder.com/100" alt="Perfil" className="controleUsuario_imagemPerfil" />
              </td>
              <td className="align-middle">{aluno.nome}</td>
              <td className="align-middle">{aluno.ano}</td>
              <td className="align-middle">{aluno.categoria}</td>
              <td className="align-middle">
              <div style={{ backgroundColor: aluno.cor, padding: '5px', borderRadius: '5px' }}>
                  {aluno.materia}
                </div>
              </td>
              <td className="d-flex justify-content-center align-items-center controleUsuario_colunaEditar controleUsuario_colunaEditar_editar">
                <ModalEditarUsuario />
                <button className="controleUsuario_botaoDeletar">
                  <i className="bi bi-trash"></i>
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
                <div className="controleUsuario_tabelaLinha"></div>
            </div>
        </div>
    );
}

export default ControleUsuario;
