import React, { useState } from 'react';
import './modalEditarUsuario.css'; 
import 'bootstrap/dist/css/bootstrap.min.css';

function ModalEditarUsuario() {
    const [showModal, setShowModal] = useState(false);

    const handleOpenModal = () => {
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
    };

    return (
        <>
            <button className="controleUsuario_botaoEditar" onClick={handleOpenModal}>
                <i className="bi bi-pencil"></i>
            </button>

            {/* Modal */}
            <div className={`modal fade ${showModal ? 'show' : ''}`} style={{ display: showModal ? 'block' : 'none' }} tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden={!showModal}>
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="exampleModalLabel">Editar Usuário</h5>
                            <button type="button" className="btn-close" onClick={handleCloseModal} aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            {/* Aqui você pode adicionar os campos de edição do usuário */}
                            <form>
                                <div className="mb-3">
                                    <label htmlFor="nome" className="form-label">Nome</label>
                                    <input type="text" className="form-control" id="nome" required />
                                </div>
                                {/* Adicione mais campos conforme necessário */}
                            </form>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" onClick={handleCloseModal}>Fechar</button>
                            <button type="button" className="btn btn-primary">Salvar Alterações</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default ModalEditarUsuario;
