import React from 'react';
import NavBarProfessor from '../../../navBar/navBarProfessor';
import '../contentColuna/index.js'


function ControleColuna() {
    
    return (
     <div>
      
      <NavBarProfessor/>
       
       
      
     </div>
       
    );
  }
  
  export default ControleColuna;
  
