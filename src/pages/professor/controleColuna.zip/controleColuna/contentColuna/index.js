import React from 'react'

function ContentColuna() {
    
    return (
     <div>
        <div className='contentColunaBodyContainer'>
            <section></section>

        </div>
     </div>
       
    );
  }
  
  export default ContentColuna;
  