import React, { useState, useEffect } from 'react';
import { getFirestore, collection, addDoc, getDocs } from "firebase/firestore"; 
import { ref, uploadBytes, getDownloadURL } from "firebase/storage"; 
import { db, storage } from '../../config/firebaseImgConfig'; 
import './cadastro.css';

function Cadastro() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [coluna, setColuna] = useState("");
  const [categoria, setCategoria] = useState("");
  const [acesso, setAcesso] = useState("");
  const [anoEscolar, setAnoEscolar] = useState("");
  const [error, setError] = useState("");
  const [imagem, setImagem] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [suggestions, setSuggestions] = useState([]);
  const [colunasExistentes, setColunasExistentes] = useState([]); // Estado para colunas existentes

  useEffect(() => {
    // Função para buscar colunas existentes no Firestore
    const fetchColunas = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "users"));
        const colunas = new Set(); // Usamos um Set para evitar duplicatas

        querySnapshot.forEach((doc) => {
          const data = doc.data();
          if (data.coluna) {
            colunas.add(data.coluna); // Adiciona a coluna ao Set
          }
        });

        setColunasExistentes(Array.from(colunas)); // Converte o Set para um array
      } catch (error) {
        console.error("Erro ao buscar colunas:", error);
        setError("Erro ao buscar colunas existentes.");
      }
    };

    fetchColunas(); // Chama a função ao montar o componente
  }, []); // O array vazio significa que o useEffect só será executado uma vez


  // Função para validar os inputs
  const validateInputs = () => {
    if (!name || !email || !password || !confirmPassword || !coluna || !categoria || !anoEscolar) {
      setError("Por favor, preencha todos os campos obrigatórios.");
      return false;
    }

    if (!email.includes("@")) {
      setError("Por favor, insira um email válido.");
      return false;
    }

    if (password !== confirmPassword) {
      setError("As senhas não coincidem.");
      return false;
    }

    if (categoria === "professor" && !acesso) {
      setError("Por favor, selecione o tipo de acesso para professores.");
      return false;
    }

    setError("");
    return true;
  };

  // Função para lidar com o upload da imagem para o Firebase Storage
  const uploadImage = async () => {
    if (imagem) {
      const storageRef = ref(storage, `imagens/${imagem.name}`);
      try {
        const snapshot = await uploadBytes(storageRef, imagem);
        const downloadURL = await getDownloadURL(snapshot.ref);
        return downloadURL; // Retorna a URL da imagem para ser salva junto com os dados do usuário
      } catch (error) {
        console.error("Erro ao fazer upload da imagem:", error);
        setError("Erro ao fazer upload da imagem.");
        return null;
      }
    } else {
      return null; // Caso nenhuma imagem tenha sido selecionada
    }
  };

  // Função para criar um novo usuário
  const criarUser = async () => {
    if (!validateInputs()) {
      return;
    }

    try {
      // Faz o upload da imagem e obtém a URL de download
      const imageUrl = await uploadImage();

      if (imagem && !imageUrl) {
        return; // Se houve erro no upload da imagem, não prosseguir
      }

      // Preparar os dados a serem enviados para o Firestore
      const userData = {
        name,
        email,
        password,
        coluna,
        categoria,
        acesso: categoria === "professor" ? acesso : "",
        anoEscolar,
        imageUrl: imageUrl || "", // Salva a URL da imagem no Firestore, ou "" se nenhuma imagem foi enviada
      };

      // Adicionar um novo documento à coleção "users"
      await addDoc(collection(db, "users"), userData);
      console.log("Novo usuário criado!");

      // Limpar os campos de input após adicionar
      setName("");
      setEmail("");
      setPassword("");
      setConfirmPassword("");
      setColuna("");
      setCategoria("");
      setAcesso("");
      setAnoEscolar("");
      setImagem(null); // Limpa a imagem
      setError(""); // Limpar mensagem de erro após criar o usuário com sucesso
    } catch (error) {
      console.error("Erro ao criar usuário:", error);
      setError("Erro ao criar o usuário, tente novamente.");
    }
  };

  const handleColunaChange = (e) => {
    const value = e.target.value;
    const formattedValue = value.charAt(0).toUpperCase() + value.slice(1);
    setColuna(formattedValue);

    if (formattedValue) {
      const filteredSuggestions = colunasExistentes.filter(col => 
        col.toLowerCase().startsWith(formattedValue.toLowerCase())
      );
      setSuggestions(filteredSuggestions);
    } else {
      setSuggestions([]);
    }
  };

  const handleSuggestionClick = (suggestion) => {
    setColuna(suggestion);
    setSuggestions([]);
  };
  return (
    <div className="cadastro-container">
      <h2>Cadastro de Usuários</h2>
      <div className="card">
        <div className="card-body">
          {error && <p className="error-message">{error}</p>} {/* Exibe a mensagem de erro */}

          <div className="input-group">
            <label>Nome:</label>
            <input 
              type='text' 
              placeholder='Nome ...'
              value={name}
              onChange={(e) => setName(e.target.value)} 
            />
          </div>

          <div className="input-group">
            <label>Email:</label>
            <input 
              type='email' 
              placeholder='Email ...'
              value={email}
              onChange={(e) => setEmail(e.target.value)} 
            />
          </div>

          <div className="input-group">
            <label>Senha:</label>
            <input 
              type='password' 
              placeholder='Senha ...'
              value={password}
              onChange={(e) => setPassword(e.target.value)} 
            />
          </div>

          <div className="input-group">
            <label>Confirmar Senha:</label>
            <input 
              type='password' 
              placeholder='Confirmar Senha ...'
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)} 
            />
          </div>

          <div className="input-group">
          <label>Coluna:</label>
            <input 
              type='text' 
              placeholder='Coluna ...'
              value={coluna}
              onChange={handleColunaChange} 
            />
            {suggestions.length > 0 && (
              <ul className="suggestions-list">
                {suggestions.map((suggestion, index) => (
                  <li key={index} onClick={() => handleSuggestionClick(suggestion)}>
                    {suggestion}
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="input-group">
            <label>Categoria:</label>
            <div className="checkbox-group">
              <label>
                <input 
                  type="radio" 
                  name="categoria" 
                  value="aluno" 
                  checked={categoria === "aluno"} 
                  onChange={(e) => setCategoria(e.target.value)} 
                />
                Aluno
              </label>
              <label>
                <input 
                  type="radio" 
                  name="categoria" 
                  value="professor" 
                  checked={categoria === "professor"} 
                  onChange={(e) => setCategoria(e.target.value)} 
                />
                Professor
              </label>
            </div>
          </div>

          {categoria === "professor" && (
            <div className="input-group">
              <label>Acesso:</label>
              <div className="checkbox-group">
                <label>
                  <input 
                    type="radio" 
                    name="acesso" 
                    value="limitado" 
                    checked={acesso === "limitado"} 
                    onChange={(e) => setAcesso(e.target.value)} 
                  />
                  Limitado
                </label>
                <label>
                  <input 
                    type="radio" 
                    name="acesso" 
                    value="ilimitado" 
                    checked={acesso === "ilimitado"} 
                    onChange={(e) => setAcesso(e.target.value)} 
                  />
                  Ilimitado
                </label>
              </div>
            </div>
          )}

          <div className="input-group">
            <label>Ano Escolar:</label>
            <select 
              value={anoEscolar} 
              onChange={(e) => setAnoEscolar(e.target.value)}
            >
              <option value="">Selecione o Ano Escolar</option>
              <option value="8ºA">8ºA</option>
              <option value="8ºB">8ºB</option>
              <option value="9ºA">9ºA</option>
              <option value="9ºB">9ºB</option>
              <option value="1ºE.M">1ºE.M</option>
              <option value="2ºE.M">2ºE.M</option>
              <option value="3ºE.M">3ºE.M</option>
              <option value="N/A">N/A</option>
            </select>
          </div>

          {/* Campo de Upload de Imagem */}
          <div className="input-group">
            <label>Foto de Perfil:</label>
            <input 
              type="file" 
              onChange={(e) => setImagem(e.target.files[0])} // Salva a imagem selecionada no estado
            />
          </div>

          {/* Botão de Cadastro */}
          <button onClick={criarUser}>Cadastrar</button>
        </div>
      </div>
    </div>
  );
}

export default Cadastro;
