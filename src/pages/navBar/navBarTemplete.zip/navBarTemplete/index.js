import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import "../../navBar/navBarTemplete/navBarTemplete.css";

export const NavBarTemplete = () => {
    return (

        <div className='containerTemplete'>
 
                <div className='style-educador'>
                <div className='navbar-texto'>
                    <h1>O EDUCADOR</h1>

                    <h6>TE MANTER INFORMADO É NOSSA MISSÃO</h6>
                </div>

                <div className='nav-visualizar-buttom'>
                <button type="button" class="btn btn-outline-light button-icon-visualizar">
                <p>VISUALIZAR PÁGINA ANTERIOR</p>
                    <i class='bx bx-chevron-right'></i>
                    </button>
                </div>

                     </div>

                     <div className='teste'>
                        
                     </div>

        </div>
    )
}

export default NavBarTemplete