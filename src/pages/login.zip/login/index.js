import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import api from '../../config/configApi';
import { Context } from "../../Context/AuthContext";
import '../login/login.css';

const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);
    const { singIn } = useContext(Context);
    const navigate = useNavigate();

    const handleLogin = async () => {
        setLoading(true);
        setError("");
        
        try {
            const response = await api.post('/login', { email, password });
            const { token, categoria } = response.data;

            // Armazenar o token e a categoria no localStorage
            localStorage.setItem('token', token);
            localStorage.setItem('categoria', categoria); // Salvar a categoria
            api.defaults.headers.Authorization = `Bearer ${token}`;

            // Autenticar o usuário no contexto
            singIn(true);

            // Redirecionar com base na categoria
            if (categoria === 'professor') {
                navigate("/dashP"); // Redireciona para a tela de professor
            } else if (categoria === 'aluno') {
                navigate("/dash"); // Redireciona para a tela de aluno
            }
        } catch (error) {
            setError(error.response ? error.response.data.mensagem : "Erro no Servidor");
        } finally {
            setLoading(false);
        }
    };
    
    return (
        <div className="login-container">
            <h1 className="login-header">Login</h1>
            <input
                type="email"
                className="login-input"
                placeholder="Digite seu email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
            />
            <input
                type="password"
                className="login-input"
                placeholder="Digite sua senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
            />
            <button 
                className="login-button"
                onClick={handleLogin} 
                disabled={loading}
            >
                {loading ? "Entrando..." : "Login"}
            </button>
            {error && <p className="login-error">{error}</p>}
        </div>
    );
};

export default Login;
